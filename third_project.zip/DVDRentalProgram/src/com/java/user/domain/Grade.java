package com.java.user.domain;

//열거형 자료.
//서로 관련있는 상수들 끼리 모아 상수들을 대표할 수 있는 이름으로 타입을 정하는 것.
public enum Grade {
	VIP, GOLD, SILVER, BRONZE
	
	
}

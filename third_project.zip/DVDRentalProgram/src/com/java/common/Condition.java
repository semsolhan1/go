package com.java.common;

public enum Condition {
	PUB_YEAR,
	NATION,
	MOVIE_NAME,
	ALL
	
}

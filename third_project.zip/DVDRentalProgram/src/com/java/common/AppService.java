package com.java.common;

public interface AppService {

	void start();
	
}
